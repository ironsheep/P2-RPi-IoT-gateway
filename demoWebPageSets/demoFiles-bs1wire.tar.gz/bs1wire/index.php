<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <meta HTTP-EQUIV="refresh" CONTENT="10">
    <title>singlePageWebSensor</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700">
    <link rel="stylesheet" href="assets/css/Footer-Basic.css">
    <link rel="stylesheet" href="assets/css/Header-Blue.css">
    <link rel="stylesheet" href="assets/css/Projects-Horizontal.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <div style="height: 70px;">
        <div class="header-blue">
            <nav class="navbar navbar-light navbar-expand-md navigation-clean-search">
                <div class="container-fluid"><a class="navbar-brand" href="#" style="text-shadow: 1px 1px rgb(0,0,0);">Propeller2 IoT Gateway</a><a class="navbar-brand page-title" href="#" style="font-size: 30px;color: var(--teal);text-shadow: 1px 1px #313437;">Demo 004</a><a class="navbar-brand demo-title" href="#" style="font-size: 14px;text-shadow: 1px 1px rgb(0,0,0);color: #ffffff;">Displaying 1-wire values</a></div>
            </nav>
        </div>
    </div>
    <section class="projects-horizontal">
        <div class="container" style="margin: 0px;padding: 15px;">
            <div class="intro">
                <p>This is a simple demo to display sensor values from an attached P2.&nbsp;</p>
                <p>This page displays a single named value found in a file written by the P2 and stored in the /status/ gateway folder.&nbsp; The value is seen to change as the page refreshes itself at which time it loads the latest value from the file.&nbsp; The P2 updates the file whenever it sees a sensor value change.</p>
            </div>
        </div>
    </section>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <p style="text-align: center;"><a href="#"><img class="img-fluid" src="assets/img/1wire_SL1000_.jpg" style="width: 270px;height: 270px;text-align: center;transform: perspective(0px) translate(0px) scale(1);"></a></p>
            </div>
            <div class="col-md-6">
                <h3 class="name">DS18B20 1-wire Sensor Demo</h3><div> <p><br>
<?php
        $statusDir = "/var/P2-RPi-ioT-gateway/status";
        $fileName = "p2-1wireValues.json";
        $fileSpec = "${statusDir}/${fileName}";
        //echo "- fileSpec=${fileSpec}<br>";
        $fileContent = file_get_contents($fileSpec);
        //echo "- fileContent=${fileContent}<br>";
        $objContent = json_decode($fileContent, true);
        //echo "- objContent=${objContent}<br>";
        //echo "<hr>Object:<br>";
        //var_dump($objContent);
        //echo "<hr>";
        $temp = $objContent['tempSensorStr'];
        echo "The value from our Sensor is: <b>${temp}</b><br>";

        // Now let's DISPLAY our RPi host info
        $procDir = "/var/P2-RPi-ioT-gateway/proc";
        $fileName = "rpiHostInfo.json";
        $fileSpec = "${procDir}/${fileName}";
        $fileContent = file_get_contents($fileSpec);
        $objContent = json_decode($fileContent, true);
        echo "<br><b>This page served from Rpi Host:</b><br>";
        foreach($objContent as $key => $value) {
            echo "&nbsp; &nbsp;<b>${key}</b>:  &nbsp;${value}<br>";
        }
?></P>
</div>
            </div>
        </div>
    </div>
    <footer class="footer-basic">
        <p class="copyright">Demo&nbsp; by Iron Sheep Productions, LLC © 2022</p>
    </footer>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>
