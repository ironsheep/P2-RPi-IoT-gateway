<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>singlePageWebControl</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700">
    <link rel="stylesheet" href="assets/css/Footer-Basic.css">
    <link rel="stylesheet" href="assets/css/Header-Blue.css">
    <link rel="stylesheet" href="assets/css/Projects-Horizontal.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <div style="height: 70px;">
        <div class="header-blue">
            <nav class="navbar navbar-light navbar-expand-md navigation-clean-search">
                <div class="container-fluid"><a class="navbar-brand" href="#" style="text-shadow: 1px 1px rgb(0,0,0);">Propeller2 IoT Gateway</a><a class="navbar-brand page-title" href="#" style="font-size: 30px;color: var(--teal);text-shadow: 1px 1px #313437;">Demo 005</a><a class="navbar-brand demo-title" href="#" style="font-size: 14px;text-shadow: 1px 1px rgb(0,0,0);color: #ffffff;">Controlling an LED String</a></div>
            </nav>
        </div>
    </div>
    <section class="projects-horizontal">
        <div class="container" style="margin: 0px;padding: 15px;">
            <div class="intro">
                <p>This is a simple demo showing control of an LED string attached to our P2 hardware.&nbsp;</p>
                <p>This page displays two color pickers which are preset to the colors the P2 is currently configured with. It shows controls which allow you to change the colors and set the display mode for the LED string.</p>
            </div>
        </div>
    </section>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <p style="text-align: center;"><a href="#"><img class="img-fluid" src="assets/img/ws2811-pinout.jpg" style="width: 270px;height: 270px;text-align: center;transform: perspective(0px) translate(0px) scale(1);"></a></p>
            </div>
            <div class="col-md-6">
                <h3 class="name">LED String Control Demo</h3>
                <div class="form-group">
                    <div>
                    <?php
                        // define variables and set to empty values
                        $ledModeError = "";
                        $color2 = $color1 = $ledMode = $comment = "";
                        //error handler function
                        function customError($errno, $errstr) {
                            echo "<span class=\"error\"> <b>Error:</b> [${errno}] ${errstr}</span>";
                        }

                        //set error handler
                        set_error_handler("customError");

                        $statusDir = "/var/P2-RPi-ioT-gateway/status";
                        $fileName = "p2-ledStatus.json";
                        $fileSpec = "${statusDir}/${fileName}";
                        //echo "- fileSpec=${fileSpec}<br>";
                        $fileContent = file_get_contents($fileSpec);
                        //echo "- fileContent=${fileContent}<br>";
                        $objContent = json_decode($fileContent, true);
                        //echo "- objContent=${objContent}<br>";
                        //echo "<hr>Object:<br>";
                        //var_dump($objContent);
                        //echo "<hr>";
                        $tmpColor1 = $objContent['color1'];
                        $tmpColor2 = $objContent['color2'];
                        $delay = $objContent['delay'];
                        $strState = $objContent['displayState'];
                        #echo "<p>DfltC1: #" . sprintf('%06x', (hexdec($tmpColor1))) . " </p>";
                        #echo "<p>DfltC2: #" . sprintf('%06x', (hexdec($tmpColor2))) . " </p>";
                        echo "<p>DfltDly: " . $delay . " </p>";
                        echo "<p>DfltMode: " . $strState . " </p>";
                        # set defaults
                        $ledMode = $strState;

                        if ($_SERVER["REQUEST_METHOD"] == "POST") {
                            if (empty($_POST["clr1"])) {
                                $color1 = "";
                            } else {
                                $color1 = test_input($_POST["clr1"]);
                            }

                            if (empty($_POST["clr2"])) {
                                $color2 = "";
                            } else {
                                $color2 = test_input($_POST["clr2"]);
                            }

                            if (empty($_POST["ledMode"])) {
                                $ledModeError = "String Display mode is required";
                            } else {
                                $ledMode = test_input($_POST["ledMode"]);
                            }
                        }

                        function test_input($data) {
                            $data = trim($data);
                            $data = stripslashes($data);
                            $data = htmlspecialchars($data);
                            return $data;
                        }
                        ?>
                        <form class="control-form" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
                            Color1:
                            <input name="clr1" value=<?php echo "#" . sprintf('%06x', (hexdec($tmpColor1))); ?> type="color">
                            <br><br>
                            Color2:
                            <input name="clr2" value=<?php echo "#" . sprintf('%06x', (hexdec($tmpColor2))); ?> type="color">
                            <br><br>
                            Delay:
                            <input type="delay" name="delay-100s" value=<?php echo "$delay"; ?> > &nbsp; [0-100]
                            <br><br>
                            Display Mode:<BR>
                            <span class="radio-button">
                                <input class="mode-select" type="radio" name="ledMode" <?php if (isset($ledMode) && $ledMode=="1") echo "checked";?> value="1">Color1
                            </span>
                            <span class="radio-button">
                                <input class="mode-select" type="radio" name="ledMode" <?php if (isset($ledMode) && $ledMode=="2") echo "checked";?> value="2">Color2
                            </span>
                            <span class="radio-button">
                                <input class="mode-select" type="radio" name="ledMode" <?php if (isset($ledMode) && $ledMode=="3") echo "checked";?> value="3">Flash
                            </span>
                            <span class="radio-button">
                                <input class="mode-select" type="radio" name="ledMode" <?php if (isset($ledMode) && $ledMode=="4") echo "checked";?> value="4">Fade
                            </span>
                            <span class="radio-button">
                                <input class="mode-select" type="radio" name="ledMode" <?php if (isset($ledMode) && $ledMode=="5") echo "checked";?> value="5">Chase
                            </span>
                            <span class="radio-button">
                                <input class="mode-select" type="radio" name="ledMode" <?php if (isset($ledMode) && $ledMode=="6") echo "checked";?> value="6">Twinkle
                            </span>
                            <span class="radio-button">
                                <input class="mode-select" type="radio" name="ledMode" <?php if (isset($ledMode) && $ledMode=="7") echo "checked";?> value="7">Off
                            </span>
                            <br><br>
                            <div class="content-right">
                                <input type="submit" name="submit" value="Submit">
                            </div>
                        </form>

                    <?php

                        if(isset($_POST['clr1']))
                            $color1= test_input($_POST["clr1"]);

                        if(isset($_POST['clr2']))
                            $color2= test_input($_POST["clr2"]);

                        if(isset($_POST['delay-100s']))
                            $delay= test_input($_POST["delay-100s"]);

                        if(isset($_POST['ledMode']))
                            $ledMode= test_input($_POST["ledMode"]);

                        // To show Hexadecimal code of the selected color
                        echo "<br>";

                        echo "<h4>Your Input:</h4>";
                        echo "Clr1: ";
                        echo $color1;
                        echo ", Clr2: ";
                        echo $color2;
                        echo ", Dly: ";
                        echo $delay;
                        if ($comment != "") {
                            echo ", Comment: ";
                            echo $comment;
                            echo "<br>";
                        }
                        echo ", Dsply Mode: ";
                        echo $ledMode;
                        // nw write our values to the control json file
                        $controlDir = "/var/www/html/P2-RPi-ioT-gateway/control";
                        $fileName = "p2-ledControl.json";
                        $cFileSpec = "${controlDir}/${fileName}";
                        #echo "<P>DBG cFileSpec=[${cFileSpec}]</P>";
                        $kvPairs[] = array('color1'=> "0x" . sprintf('%06x', (hexdec($tmpColor1))),
                                           'color2'=> "0x" . sprintf('%06x', (hexdec($tmpColor2))),
                                           'delay'=> $delay,
                                        'displayState'=> $ledMode);
                        $fileContent = json_encode($kvPairs, JSON_PRETTY_PRINT);
                        #echo "<PRE>" . $fileContent . "</PRE>";
                        if($fp = fopen($cFileSpec, 'w')) {
                            fwrite($fp, $fileContent);
                            fclose($fp);
                        }
                    ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <section class="projects-horizontal">
        <div class="container" style="margin: 0px;padding: 15px;">
            <div class="intro">
            <?php
                // Now let's DISPLAY our RPi host info
                $procDir = "/var/P2-RPi-ioT-gateway/proc";
                $fileName = "rpiHostInfo.json";
                $fileSpec = "${procDir}/${fileName}";
                $fileContent = file_get_contents($fileSpec);
                $objContent = json_decode($fileContent, true);
                echo "<br><b>This page served from Rpi Host:</b><br>";
                foreach($objContent as $key => $value) {
                    echo "&nbsp; &nbsp;<b>${key}</b>:  &nbsp;${value}<br>";
                }
                ?>
            </div>
        </div>
    </section>
    <footer class="footer-basic">
        <p class="copyright">Demo&nbsp; by Iron Sheep Productions, LLC © 2022</p>
    </footer>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>
